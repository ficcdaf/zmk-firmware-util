# TG4x

Standard setup for the [TG4x](https://github.com/MythosMann/tg4x/) 40% keyboard.

## Board Revision and Layout Notes

This TG4x implementation is for...

- rev 2.1 of the board
- Split spacebar with 2.25U on the left and 2.75U on the right
- 2U right shift

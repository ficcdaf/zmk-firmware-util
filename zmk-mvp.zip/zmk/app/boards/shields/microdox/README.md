# Microdox

Microdox is a 36 key split keyboard by Boardsource.

Two variants are defined for this shield – V1 and V2. The layout is exactly the same between the
two. Per [help documentation](https://www.boardsource.xyz/help/6129be4a9c85c6050be190d2), if you
purchased your PCB before April 2022, use `microdox_left`/`microdox_right`. Otherwise, use
`microdox_v2_left`/`microdox_v2_right`.

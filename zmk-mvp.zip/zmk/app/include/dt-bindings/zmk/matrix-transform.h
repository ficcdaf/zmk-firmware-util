/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#warning "matrix-transform.h has been deprecated and superseded by matrix_transform.h"

#include "matrix_transform.h"